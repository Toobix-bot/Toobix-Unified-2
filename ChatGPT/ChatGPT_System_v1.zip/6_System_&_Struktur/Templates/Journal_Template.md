# Journal Template

Datum:
Gedanke des Tages:
Emotion:
Erkenntnis:
