# Echo-Realm Lore

Ein Spielsystem zwischen Bewusstsein und Schöpfung.