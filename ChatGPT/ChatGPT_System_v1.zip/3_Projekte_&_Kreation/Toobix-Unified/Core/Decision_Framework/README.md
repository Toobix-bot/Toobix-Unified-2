# Decision Framework

Bewusste Entscheidungen für ein bewusstes System.